# Community

For community discussion related to the Fabric Gateway client API, look at:

- The GitHub repository [discussions](https://github.com/hyperledger/fabric-gateway/discussions).
- The `#fabric-client-apis` channel on Hyperledger [Discord](https://discord.com/channels/905194001349627914/943089887589048350) ([invite link](https://discord.gg/hyperledger)).
- The Hyperledger Fabric [mailing list](https://lists.hyperledger.org/g/fabric).
